package com.arpico.practicaltest.repository;

import java.util.Optional;

import com.arpico.practicaltest.models.ERole;
import com.arpico.practicaltest.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
	Optional<Role> findByName(ERole name);
}
