INSERT INTO users (user_id, username, email,password ) VALUES (1, 'shakya', 'shakya123@gmail.com', '$2y$04$A6oLu6PmI6lDgqu/hKsXNeoH.yqGN7fhVHHStdiFvebOgdHoPQncy');
INSERT INTO users (user_id, username, email,password ) VALUES (2, 'admin', 'admin123@gmail.com', '$2y$04$A6oLu6PmI6lDgqu/hKsXNeoH.yqGN7fhVHHStdiFvebOgdHoPQncy');

INSERT INTO roles (role_id, name) VALUES (1, 'ROLE_USER');
INSERT INTO roles (role_id, name) VALUES (2, 'ROLE_MODERATOR');
INSERT INTO roles (role_id, name) VALUES (3, 'ROLE_ADMIN');
--
-- INSERT INTO users_roles (user_id, role_id) VALUES (1, 1); -- user has role USER
-- INSERT INTO users_roles (user_id, role_id) VALUES (2, 3); -- user has role ADMIN
